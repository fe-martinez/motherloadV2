package jugador;

public enum TipoMovimiento {
	ARRIBA,
	ABAJO,
	DERECHA,
	IZQUIERDA
}
