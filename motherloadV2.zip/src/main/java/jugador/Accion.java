package jugador;

public interface Accion {
	public boolean aplicar();
}
