package tiendas;

import jugador.Jugador;

public interface EstacionDeMantenimiento {
	public void vender(Jugador jugador, double cantidad);
}
