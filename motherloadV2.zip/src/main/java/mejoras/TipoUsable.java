package mejoras;

public enum TipoUsable {
	DINAMITA,
	EXPLOSIVOS,
	REPAIR,
	TANQUE_EXTRA,
	TELEPORT;
}
