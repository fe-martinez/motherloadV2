package minerales;

public enum TipoDeBloque {
	BRONCE,
	COBRE,
	DIAMANTE,
	HIERRO,
	ORO,
	PLATA,
	TIERRA,
	AIRE
}
