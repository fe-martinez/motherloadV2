package terreno;

public interface Bloque {
	public char getBloqueID();
}
