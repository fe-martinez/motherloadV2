package terreno;

public enum TipoEntidad {
	AIRE,
	JUGADOR,
	TIENDA;
}
