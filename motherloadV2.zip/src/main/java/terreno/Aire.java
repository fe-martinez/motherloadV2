package terreno;

public class Aire implements Bloque{
	public static final char LETRA = ' ';
	
	//Devuelve la letra que representa a la clase
	public char getBloqueID() {
		return Aire.LETRA;
	}

	public TipoEntidad getTipoEntidad() {
		return TipoEntidad.AIRE;
	}
}