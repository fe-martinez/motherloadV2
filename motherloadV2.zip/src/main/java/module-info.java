module algo3.motherloadV2 {
    requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
	requires javafx.media;
    exports algo3.motherloadV2;
}
