# Pruebas

* Probar los movimientos
* Probar que cuando se taladra un bloque específico, el personaje recolecta lo que tiene que recolectar (y no recolecta lo que no debe).
* Probar que cuando se taladra un bloque, el bloque desaparece.
* Probar que los movimientos son dentro de rangos válidos.
* Probar que no se generan cosas fuera de rango.
* Probar que cuando se mueve, pierde vida y usa combustible.
* Probar que al comprar vida o combustible este se suma correctamente.
* Probar que no se pueda comprar sin plata/con menos plata de la necesaria.
* Probar que al vender minerales, estos se eliminan correctamente.
* Probar que al vender minerales se gana la plata correspondiente.
* Probar que al comprar una mejora, la misma se aplica correctamente.
* Límite de inventario (no se puede exceder)
* No se puede mover hacia arriba en ciertos bloques (en la mayoría)
* Cuando se compra con un valor predeterminado, solo se gasta la plata necesaria.
* Se mueve hacia arriba solo si el bloque es aire.
* Se mueve en cualquier direacción menos arriba para todos los bloques que no son aire.
