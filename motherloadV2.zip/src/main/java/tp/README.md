# Cosas a mencionar:
* El manejo de la ubicacion del pj esta rarazo, pero con la implementacion actual era eso o dos loops que borren al pj anterior.
* Los getters y setters de Posicion se me hacian mas complicados que los getters y setters por defecto, por eso los cambie.
* Aire y Tierra son mas anemicas que no se. Habria que ver la manera de que no tengan que tener precio, Jugador tambien es un bloque.
* Esos getters y setters que puse en Jugador tambien estan medio feazos.
* Cambie de tipoDeMineral a tipoDeBloque
* Se me hacen raras las coordenadas porque estan invertidas, es decir, como se imprime [i]-[j], la i es la y de un sistema de coordenadas. Eso o estoy cansado jaja
* Creando un loop se podria "jugar", mover el & por la matriz va. Creo que lo proximo a implementar seria que cuando pase por arriba de un bloque, este se transforme en aire. Por el lado de las tiendas tambien se deberia implementar lo de ganar dinero.
* Hacer terrenos pre-diseñados? Veremos veremos (NO ES IMPORTANTE NI URGENTE ES LO ÚLTIMO A CHUSMEAR)

# Dudas:

* Usar matriz[][] para la implementación
* La matriz es de bloques? Ta bien?
* Aplicación de Factory Method: nos quedan clases que no hacen una goma :P
