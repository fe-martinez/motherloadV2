package tp;

public enum EstadoDelJuego {
	JUGANDO,
	PERDIDO,
	GANADO
}
