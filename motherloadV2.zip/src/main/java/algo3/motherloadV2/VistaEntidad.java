package algo3.motherloadV2;

public interface VistaEntidad {
	public void mostrar();
}
